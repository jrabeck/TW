Hello ThoughtWorks! 

This application is far from perfect but I'm proud to say that after much work and research it runs! You pretty much just need to compile and run it, the input is already there in the directory, I only made one seperate file for the class Item, and a copy of the instructions is included for convenience. I didn't make my way to user input, but as long as the input is formated exactly the way it was formatted in the assignment in a .txt file, this should run. It also accommodates multiple item quantities. 

Also, I have 74.63 at the end instead of the prescribed 74.68. 5% of 11.25 is 0.5625, which would round to 0.55 as the closest 0.05, making sales taxes 6.65, so that was my logic there. there's a bug with the 7.64 sales tax since part of the rounding is happening after the value was determined. I can got it to 7.66 by repeating the process with the rounding but that was just longer and not really better. 
